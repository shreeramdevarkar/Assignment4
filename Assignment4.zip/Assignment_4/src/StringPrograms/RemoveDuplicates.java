package StringPrograms;

import java.util.*;   
 
class RemoveDuplicates   
{   
  public void removeDuplicates(String str)   
  {     
      LinkedHashSet<Character> set = new LinkedHashSet<>();     
      for(int i=0;i<str.length();i++)   
          set.add(str.charAt(i));   
            
      for(Character ch : set)   
          System.out.println(ch);   
  } 
  
}  

class RemoveDuplicatespgm{
	public static void main(String args[]) {
		String input="aabsccdad";
		RemoveDuplicates obj=new RemoveDuplicates();
		obj.removeDuplicates(input);
	}
}
      
